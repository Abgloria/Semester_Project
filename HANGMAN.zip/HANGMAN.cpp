#include <iostream>
#include <ctime>
#include <string>
#include <cstdlib>
using namespace std;

string words[] = {"nigeria", "ghana", "mountain", "favourite", "science"};
bool foundPos[20];
int chancesWrongGuess = 4;
int noOfWrongGuess = 0;

void startScreen(string chosenWord) {
    cout << "!!Welcome to Hangman game!!" << endl;
    cout << "===========================\n" << endl;
    cout << "You have " << chancesWrongGuess << " chances of wrong decision." << endl;
    for (int i=0; i<chosenWord.length(); i++) {
        cout << " _ ";
    }

}

string getRandWord(){
    srand(time(0));
    // Generate a random number between 0 and 4 inclusive
    int randomNumber = rand() % 5;
    return words[randomNumber];
}

char userLetter() {
    char guessLetter;
    cout << "\n\nEnter letter: ";
    cin >> guessLetter;
    return guessLetter;
}

bool wordIsComplete(string word){
    int foundCount = 0;
    for(int i=0; i< word.length();i++) {
        if (foundPos[i]) ++foundCount;
    }

    if (foundCount == word.length()) {
        cout << "\nWord found. You won";
        return true;
    }

    return false;
}
void correctGuess(string word, char gL){
    for(int i=0;i<word.length();i++) {
        if (word[i]==gL || foundPos[i]) {
            cout << word[i];
            foundPos[i] = true;
        }
        else {
                cout << " _ ";
        }
    }
}
void incorrectGuess(string word){
    noOfWrongGuess += 1;
    cout << "Incorrect guess. You have " <<chancesWrongGuess-noOfWrongGuess << " chances remaining." << endl;

    if (noOfWrongGuess == chancesWrongGuess) {
        cout << "You lost.\n\nWord was " << word;
    }
}

int main() {
    string word = getRandWord();
    startScreen(word);
    while (chancesWrongGuess>noOfWrongGuess && !wordIsComplete(word)) {
        char guessedLetter = userLetter();
        size_t position = word.find(guessedLetter);
        if (position != string::npos) correctGuess(word,guessedLetter);
        else incorrectGuess(word);
    }

    return 0;
}

